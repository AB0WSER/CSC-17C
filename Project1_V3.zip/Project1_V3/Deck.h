
/* 
 * File:   Deck.h
 * Author: Andrew
 *
 * Created on November 3, 2024, 1:10 PM
 */


#include "CardClass.h"

#ifndef DECK_H
#define DECK_H


#include "CardClass.h"
#include <set>

class Deck : public Card {
protected:
    static const int SIZE = 52; // Total number of cards in a deck
    Card cards[SIZE];          // Array to hold all cards
    int top;                   // Index of the top card in the deck
    set<string> dealtCards;  // NEW: To track unique card strings

public:
    // Constructor to initialize the deck
    Deck();

    // Function to shuffle the deck
    void shuffle();

    // Function to deal a card from the deck
    Card deal();

    // Destructor
    ~Deck();
};
#endif /* DECK_H */

