/* 
 * File:   BlackJack.h
 * Author: Andrew
 *
 * Created on December , 2024, 1:15 PM
 */

#ifndef BLACKJACK_H
#define BLACKJACK_H

#include "Deck.h"
#include "PlayerClass.h"
#include "Record.h"

class BlackJack {
protected:
    Deck deck;              // Deck of cards used in the game
    Player<int> player;     // Player participating in the game
    Player<int> dealer;     // Dealer participating in the game
    GameRecord record;      // Game record for tracking stats

public:
    // Constructor to initialize the game
    BlackJack(const string& playerName, float initialMoney);

    // Function to play the game
    void play();

    // Overloaded operator to display the game stats
    friend ostream& operator<<(ostream& os, const BlackJack& game);
    
    //helper functions
    void updateBalance(float amount);
    float getBalance() const;
    // Destructor
    ~BlackJack();
};


#endif /* BLACKJACK_H */

