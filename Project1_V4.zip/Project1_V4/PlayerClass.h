/* 
 * File:   PlayerClass.h
 * Author: Andrew
 *
 * Created on December 15, 2024, 1:11 PM
 */

#ifndef PLAYERCLASS_H
#define PLAYERCLASS_H

#include <list>
#include "CardClass.h"

using namespace std;

template <typename T>
class Player {
protected:
    string name;         // Name of the player
    list<Card> hand;   // Cards held by the player
    T score;             // Player's score (templated for flexibility)
    float money;         // Player's money balance

public:
    // Constructor to initialize player with a name
    Player(const string& name, float initialMoney) 
        : name(name), score(0), money(initialMoney) {}

    // Function to add a card to the player's hand
    void addCard(const Card& card) {
        hand.push_back(card);
    }

    // Function to calculate the player's score
    T calculateScore() const {
        T total = 0;
        int aces = 0; // Track number of Aces for special handling

        for (const Card& card : hand) {
            total += card.getValue();
            if (card.getRank() == "Ace") ++aces;
        }

        while (total > 21 && aces > 0) {
            total -= 10; // Downgrade Ace from 11 to 1
            --aces;
        }

        return total;
    }

    // Function to display the player's hand
    void showHand() const {
        cout << name << "'s hand:" << endl;
        for (const Card& card : hand) {
            cout << card.getRank() << " of " << card.getSuit() << endl;
        }
    }

    // Function to update money balance
    void updateMoney(float amount) {
        money += amount;
    }

    // Function to get current money balance
    float getMoney() const {
        return money;
    }

    // Function to reset the player's hand
    void resetHand() {
        hand.clear();
        score = 0;
    }

    // Check if the hand is a pair
    bool isPair() const {
         if (hand.size() != 2) return false;

        auto it = hand.begin();
        string firstRank = it->getRank();
        ++it;
        string secondRank = it->getRank();

        return firstRank == secondRank;
    }

    // Function to split the hand (returns the second card)
    Card splitHand() {
        if (isPair()) {
            auto it = hand.begin();
            advance(it, 1);                 // Move iterator to second card
            Card secondCard = *it;
            hand.erase(it);                 // Erase the second card
            return secondCard;
        } else {
            throw logic_error("Cannot split a non-pair hand");
        }
    }

    // Destructor
    ~Player() {}
};
#endif /* PLAYERCLASS_H */

