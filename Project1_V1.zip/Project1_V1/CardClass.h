/* 
 * File:   CardClass.h
 * Author: Andrew
 *
 * Created on November , 2024, 2:53 PM
 */


#ifndef CARDCLASS_H
#define CARDCLASS_H


#include <string>
#include <iostream>
using namespace std;

class Card {
protected:
    string suit; // Suit of the card (e.g., Hearts, Spades)
    string rank; // Rank of the card (e.g., Ace, 2, King)
    int value;   // Numeric value of the card (used for scoring in Blackjack)

public:
    // Default constructor
    Card();

    // Parameterized constructor to initialize card properties
    Card(const string& suit, const string& rank, int value);

    // Getters for card properties
    string getSuit() const;
    string getRank() const;
    int getValue() const;

    // Destructor
    virtual ~Card();
};

#endif /* CARDCLASS_H */

