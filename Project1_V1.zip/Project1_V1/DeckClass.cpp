/* 
 * File:   main.cpp
 * Author: Andrew Bowser
 * Created on November , 2024 at 1:03 PM
 *Purpose: CardClass.cpp
 */

//System libraries
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

#include "Deck.h"
#include <algorithm>
#include <ctime>

// Constructor to initialize the deck
Deck::Deck() : top(0) {
    string suits[] = {"Hearts", "Diamonds", "Clubs", "Spades"};
    string ranks[] = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};
    int values[] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10, 11};

    int index = 0;
    for (const string& suit : suits) {
        for (int i = 0; i < 13; ++i) {
            cards[index++] = Card(suit, ranks[i], values[i]);
        }
    }
}

// Function to shuffle the deck
void Deck::shuffle() {
    srand(static_cast<unsigned>(time(0)));
    std::random_shuffle(cards, cards + SIZE);
    top = 0; // Reset the top index after shuffling
}

// Function to deal a card from the deck
Card Deck::deal() {
    if (top < SIZE) {
        return cards[top++];
    } else {
        throw out_of_range("No cards left in the deck");
    }
}

// Destructor
Deck::~Deck() {
    // No dynamic memory used, so no special cleanup required
}