/* 
 * File:   Record.h
 * Author: Andrew Bowser
 *
 * Created on November 1, 2024, 2:10 PM
 */

#ifndef RECORD_H
#define RECORD_H

#include <vector>
#include <string>
#include <unordered_map>
using namespace std;

class GameRecord {
public:
    int gamesPlayed;   // Number of games played
    int gamesWon;      
    // Default constructor
    GameRecord();

    // Function to update the record for a win
    void recordWin();

    // Function to display the game record
    void display() const;

    // Destructor
    ~GameRecord();

    // Friend class declaration
    friend class BlackJack;
    
   // Recursive merge sort for record lines
    void mergeSort(vector<string>& arr, int left, int right);
    void merge(vector<string>& arr, int left, int mid, int right);
    void sortGameRecords();  // Loads file, sorts, and writes back
    //Hashing Functions
    void loadWins();           // Load map from Record.txt
    int getWins(const string&); // Return number of wins for player
    
    struct TreeNode {
    string name;
    int score;
    TreeNode* left;
    TreeNode* right;
    TreeNode(string n, int s);
};
//Trees
    void insert(TreeNode*& root, const string& name, int score);
    void inorder(TreeNode* root);
    void buildPlayerTree();
    //Graphs
    void buildCardGraph();                     // Build the graph
    void printConnections(const string& card); // Show connected cards
};


#endif /* RECORD_H */

