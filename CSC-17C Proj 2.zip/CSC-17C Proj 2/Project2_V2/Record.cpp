/* 
 * File:   main.cpp
 * Author: Andrew Bowser
 * Created on November , 2024 at 1:03 PM
 *Purpose: CardClass.cpp
 */

//System libraries

using namespace std;

#include "Record.h"
#include <iostream>
#include <vector>
#include <fstream>
#include <unordered_map>
using namespace std;

struct TreeNode {
    string name;
    int score;
    TreeNode *left, *right;
    TreeNode(string n, int s) : name(n), score(s), left(nullptr), right(nullptr) {}
};

// Default constructor
GameRecord::GameRecord() : gamesPlayed(0), gamesWon(0) {}

// Function to update the record for a win
void GameRecord::recordWin() {
    ++gamesPlayed;
    ++gamesWon;
}

// Function to display the game record
void GameRecord::display() const {
    cout << "Games Played: " << gamesPlayed << endl;
    cout << "Games Won: " << gamesWon << endl;
}
void merge(vector<string>& arr, int left, int mid, int right) {
    vector<string> temp;
    int i = left, j = mid + 1;
    while (i <= mid && j <= right)
        temp.push_back(arr[i] < arr[j] ? arr[i++] : arr[j++]);
    while (i <= mid) temp.push_back(arr[i++]);
    while (j <= right) temp.push_back(arr[j++]);
    for (int k = 0; k < temp.size(); k++) arr[left + k] = temp[k];
}

void mergeSort(vector<string>& arr, int left, int right) {
    if (left >= right) return;
    int mid = (left + right) / 2;
    mergeSort(arr, left, mid);
    mergeSort(arr, mid + 1, right);
    merge(arr, left, mid, right);
}

// Call this to read and sort records
void sortGameRecords() {
    ifstream in("Record.txt");
    vector<string> lines;
    string line;
    while (getline(in, line)) lines.push_back(line);
    in.close();
    mergeSort(lines, 0, lines.size() - 1);
    ofstream out("Record.txt");
    for (const string& l : lines) out << l << endl;
}

unordered_map<string, int> winMap;
void loadWins() {
    ifstream file("Record.txt");
    string name;
    int wins;
    while (file >> name >> wins)
        winMap[name] = wins;
}

int getWins(const string& playerName) {
    return winMap.count(playerName) ? winMap[playerName] : 0;
}
void insert(TreeNode*& root, const string& name, int score) {
    if (!root) root = new TreeNode(name, score);
    else if (score < root->score) insert(root->left, name, score);
    else insert(root->right, name, score);
}

void inorder(TreeNode* root) {
    if (!root) return;
    inorder(root->left);
    cout << root->name << ": " << root->score << endl;
    inorder(root->right);
}

void buildPlayerTree() {
    TreeNode* root = nullptr;
    ifstream file("Record.txt");
    string name;
    int score;
    while (file >> name >> score)
        insert(root, name, score);
    inorder(root);  // Print in sorted order
}

// Destructor
GameRecord::~GameRecord() {}