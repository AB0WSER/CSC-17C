/* 
 * File:   main.cpp
 * Author: Andrew Bowser
 * Created on November , 2024 at 1:03 PM
 *Purpose: CardClass.cpp
 */

//System libraries

using namespace std;

#include "Record.h"
#include <iostream>
#include <vector>
#include <fstream>
using namespace std;

// Default constructor
GameRecord::GameRecord() : gamesPlayed(0), gamesWon(0) {}

// Function to update the record for a win
void GameRecord::recordWin() {
    ++gamesPlayed;
    ++gamesWon;
}

// Function to display the game record
void GameRecord::display() const {
    cout << "Games Played: " << gamesPlayed << endl;
    cout << "Games Won: " << gamesWon << endl;
}
void merge(vector<string>& arr, int left, int mid, int right) {
    vector<string> temp;
    int i = left, j = mid + 1;
    while (i <= mid && j <= right)
        temp.push_back(arr[i] < arr[j] ? arr[i++] : arr[j++]);
    while (i <= mid) temp.push_back(arr[i++]);
    while (j <= right) temp.push_back(arr[j++]);
    for (int k = 0; k < temp.size(); k++) arr[left + k] = temp[k];
}

void mergeSort(vector<string>& arr, int left, int right) {
    if (left >= right) return;
    int mid = (left + right) / 2;
    mergeSort(arr, left, mid);
    mergeSort(arr, mid + 1, right);
    merge(arr, left, mid, right);
}

// Call this to read and sort records
void sortGameRecords() {
    ifstream in("Record.txt");
    vector<string> lines;
    string line;
    while (getline(in, line)) lines.push_back(line);
    in.close();
    mergeSort(lines, 0, lines.size() - 1);
    ofstream out("Record.txt");
    for (const string& l : lines) out << l << endl;
}
// Destructor
GameRecord::~GameRecord() {}