/* 
 * File:   main.cpp
 * Author: Andrew Bowser
 * Created on November , 2024 at 1:03 PM
 *Purpose: CardClass.cpp
 */


using namespace std;


#include "CardClass.h"
#include <iostream>
// Default constructor
Card::Card() : suit(""), rank(""), value(0) {
    // Initializes an empty card
}

// Parameterized constructor
Card::Card(const string& suit, const string& rank, int value) 
    : suit(suit), rank(rank), value(value) {
    // Initializes a card with given suit, rank, and value
}

// Getter for suit
string Card::getSuit() const {
    return suit;
}

// Getter for rank
string Card::getRank() const {
    return rank;
}

// Getter for value
int Card::getValue() const {
    return value;
}

// Destructor
Card::~Card() {
    // No dynamic memory used, so no special cleanup required
}
