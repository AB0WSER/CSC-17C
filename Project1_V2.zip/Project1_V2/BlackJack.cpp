/* 
 * File:   main.cpp
 * Author: Andrew Bowser
 * Created on November , 2024 at 1:03 PM
 *Purpose: CardClass.cpp
 */

using namespace std;

#include "BlackJack.h"

// Constructor to initialize the game
BlackJack::BlackJack(const string& playerName, float initialMoney) 
    : player(playerName, initialMoney), dealer("Dealer", 0) {
    deck.shuffle();
}

// Function to play the game
void BlackJack::play() {
    float bet;
    cout << "Enter your bet amount: ";
    cin >> bet;

    // Validate bet
    if (bet <= 0 || bet > player.getMoney()) {
        cout << "Invalid bet amount." << endl;
        return;
    }

    // Deal initial cards
    player.addCard(deck.deal());
    dealer.addCard(deck.deal());

    player.addCard(deck.deal());
    dealer.addCard(deck.deal());

    player.showHand();
    cout << "Your score: " << player.calculateScore() << endl;

    // Check for splitting pairs
    char splitChoice;
    if (player.isPair()) {
        cout << "You have a pair! Do you want to split? (Y/N): ";
        cin >> splitChoice;
        if (toupper(splitChoice) == 'Y') {
            Card secondCard = player.splitHand();
            Player<int> secondHand(player);
            secondHand.addCard(deck.deal());
            player.addCard(deck.deal());

            cout << "First hand:" << endl;
            player.showHand();
            cout << "Score: " << player.calculateScore() << endl;

            cout << "Second hand:" << endl;
            secondHand.showHand();
            cout << "Score: " << secondHand.calculateScore() << endl;
        }
    }

    // Check for doubling down
    char doubleDownChoice;
    cout << "Do you want to double down? (Y/N): ";
    cin >> doubleDownChoice;
    if (toupper(doubleDownChoice) == 'Y') {
        bet *= 2;
        player.addCard(deck.deal());
        cout << "You doubled down and received one card." << endl;
        player.showHand();
        cout << "Your score: " << player.calculateScore() << endl;
    }

    // Dealer logic
    while (dealer.calculateScore() < 17) {
        dealer.addCard(deck.deal());
    }

    // Show dealer's hand
    dealer.showHand();
    cout << "Dealer's score: " << dealer.calculateScore() << endl;

    // Determine winner
    int playerScore = player.calculateScore();
    int dealerScore = dealer.calculateScore();

    if (playerScore > 21) {
        cout << "You busted! Dealer wins!" << endl;
        player.updateMoney(-bet);
    } else if (dealerScore > 21 || playerScore > dealerScore) {
        cout << "You win!" << endl;
        player.updateMoney(bet);
        record.recordWin();
    } else if (playerScore == dealerScore) {
        cout << "It's a tie! No money won or lost." << endl;
    } else {
        cout << "Dealer wins!" << endl;
        player.updateMoney(-bet);
        }

    // Display current money balance
    cout << "Your current balance: $" << player.getMoney() << endl;

    // Check if the player wants to play another hand
    char playAgain;
    cout << "Do you want to play another hand? (Y/N): ";
    cin >> playAgain;

    if (toupper(playAgain) == 'Y') {
        player.resetHand();
        dealer.resetHand();
        play(); // Recursively call the play function for another hand
    } else {
        cout << "Thank you for playing Blackjack!" << endl;
        record.display();
    }
}

// Overloaded operator to display the game stats
ostream& operator<<(ostream& os, const BlackJack& game) {
    os << "Player: " << game.player.getMoney() << " | Games Played: " << game.record.gamesPlayed
       << " | Games Won: " << game.record.gamesWon;
    return os;
}

// Destructor
BlackJack::~BlackJack() {
    // Cleanup handled automatically
}